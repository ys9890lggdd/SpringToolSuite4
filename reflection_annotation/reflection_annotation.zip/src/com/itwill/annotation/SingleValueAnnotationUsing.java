package com.itwill.annotation;

@SingleValueAnnotation(id = 1)
public class SingleValueAnnotationUsing {
}