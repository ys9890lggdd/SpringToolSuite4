package com.itwill.annotation;

@MyClassAnnotation(name = "someName", value = "Hello World")
public class MyClassAnnotationUsing {
}