package com.itwill.annotation;

public @interface SingleValueAnnotation {
	int id();
}