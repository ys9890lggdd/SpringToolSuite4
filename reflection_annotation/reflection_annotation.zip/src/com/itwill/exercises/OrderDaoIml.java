package com.itwill.exercises;
@Repository(value = "orderDao")
public class OrderDaoIml {

}
