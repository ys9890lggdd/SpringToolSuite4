package com.itwill.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
