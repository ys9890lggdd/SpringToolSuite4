package com.itwill.annotation;

public @interface MakerAnnotation {
	
}