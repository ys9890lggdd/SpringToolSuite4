package com.mybatis3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringApplicationMybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
