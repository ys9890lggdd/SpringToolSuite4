package com.itwill.exception;

public class BusinessException1 extends Exception{
	public BusinessException1(String msg) {
		super(msg);
	}
}
