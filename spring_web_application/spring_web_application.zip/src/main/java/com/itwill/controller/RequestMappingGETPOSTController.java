package com.itwill.controller;

public class RequestMappingGETPOSTController {

	public String get_login_form() {
		return "";
	}

	public String post_login_action() {

		return "";
	}
}
